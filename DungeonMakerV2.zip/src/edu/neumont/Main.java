package edu.neumont;

public class Main {

    public static void main(String[] args) {
        Model model = new Model();
        model.run();
    }
}
